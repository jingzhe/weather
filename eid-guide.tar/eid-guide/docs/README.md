---
home: true

footer: Copyright Nordea
---
# Housing loan
Buying a home is a responsible and flexible investment. Get a well-thought-out loan decision even within an hour. Nordea’s quick housing loan is an alternative designed to endure life's challenges and always fit your and your household's needs. The loan period can be 35 years.

# How are you prepared for an increase in your monthly repayments?
Protect yourself against a rise in interest rates and unexpected changes to your loan in advance.

Read more about interest rate hedging